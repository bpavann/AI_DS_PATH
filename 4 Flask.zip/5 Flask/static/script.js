document.getElementById('marksForm').addEventListener('submit', function (e) {
  e.preventDefault();

  let total = 0;
  for (let i = 1; i <= 5; i++) {
    const mark = parseInt(document.getElementById(`subject${i}`).value);
    if (isNaN(mark) || mark < 0) {
      alert(`Please enter a valid mark for Subject ${i}`);
      return;
    }
    total += mark;
  }

  document.getElementById('result').innerText = `🎯 Total Marks: ${total}`;
});
