#Dynamic URL
#Flask variables Ruls
#URL building
from flask import Flask,redirect,url_for

app=Flask(__name__)

@app.route('/')
def home():
    return "welcome to my AI World"

@app.route('/success/<score>') #Dynamic Url Building
def success(score):
    return "The Employee success has the score of "+ str(score)

@app.route('/fail/<score>') #Dynamic Url Building
def fail(score):
    return "The Employee fail has the score of "+ str(score)

@app.route('/result/<score>') 
def result(score):
    result=""
    if int(score)>50:
        result="success"
    else:
        result="fail"
    return redirect(url_for(result,score=score)) #URL Building

if __name__=="__main__":
    app.run(debug=True)
