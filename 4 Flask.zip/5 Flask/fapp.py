from flask import Flask

#WSGI application
#Flask is a micro web framework for Python
app=Flask(__name__)

@app.route('/') #Decorator to define the route
def home():
    return "welcome to my AI World"

if __name__=="__main__": #Run the application
    app.run(debug=True) #debug=True enables debug mode
# This allows for automatic reloading and better error messages
# The application will run on http://