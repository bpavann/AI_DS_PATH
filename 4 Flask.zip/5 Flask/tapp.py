#Dynamic URL
#Flask variables Ruls
#URL building
from flask import Flask,redirect,url_for,render_template,request
'''
Jinja Templates Engine
#{%   %} for Conditions like if,for etc
#{{     }} Expression to printOut
#{#   #} For comments
'''
  
app=Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/success/<int:score>') #Dynamic Url Building
def success(score):
    res=""
    if score>50:
        res="SUCCESS"
    else:
        res="FAIL"
    exp={'score':score,'res':res}
    return render_template('res.html',result=exp)



@app.route('/fail/<int:score>') #Dynamic Url Building
def fail(score):
    return render_template('result.html',result=score)

@app.route('/result/<int:score>') 
def result(score):
    res=""
    if int(score)>50:
        res="Success"
    else:
        res="Fail"
    return redirect(url_for(result,result=res)) #URL Building

@app.route('/submit',methods=['POST','GET'])
def submit():
    if request.method=='POST':
        math=float(request.form['math'])
        stats=float(request.form['stats'])
        eda=float(request.form['eda'])
        ml=float(request.form['ml'])
        dl=float(request.form['dl'])
        total=(math+stats+eda+ml+dl)/5
        
        if total > 50:
            return redirect(url_for('success', score=int(total)))
        else:
            return redirect(url_for('fail', score=int(total)))
            
    return render_template('home.html')   #URL Building        

if __name__=="__main__":
    app.run(debug=True)
