#Constraints
/*
SQL constraints are used to specified any rule for the records in the table.
Constraints can be used to limit the type of the data that can be go into other tables.
It ensures that the accuracy and reliability of the record in the table.
If there is any violation between the contraints and the records action,the actions absorted.
Constraints can be column level and table level.
Column level constraints are apply to columns, Table level contraints are apply to whole table.

Not null
Unique
Primary key
Foreign key
Check
Default
Index
*/

create database mysql;
use mysql;
#Not null
create table student(id integer not null,firstname varchar(15) not null,lastname varchar(15) not null, age integer);

#if we want to modify age inti not null from null
alter table student modify age int not null;

#Unique
create table person(id int not null,firstname varchar(15) not null, lastname varchar(15) not null,age int not null,unique(id));
insert into person(id,firstname,lastname,age) 
values 
(1,'pavan','kumar',25),
(2,'kc','y',22),
(3,'suri','f',24),
(4,'tharun','n',23),
(5,'anji','k',26);

alter table person add unique(id);

#Multiple feature make unique as one feature
alter table person add constraint us_person unique(age,firstname);
#Ensures that the combination of age and firstname is unique across the table.

#drop unique constraints
alter table person drop index us_person;

#Primary Key
create table person1(id int not null,firstname varchar(15)not null,lastname varchar(25),age int, constraint pk_person primary key(age,lastname));

#drop constraint
alter table person1 drop primary key;

#add primary key
alter table person1 add primary key(id);

drop table person;

create table person(
id int not null,
firstname varchar(25) not null,
lastname varchar(25) not null,
age int);
desc person;
alter table person add constraint pk_person primary key(id,age);
alter table person drop primary key;
drop table person;

#Foreign Key
create table person(
id int not null,
firstname varchar(25) not null,
lastname varchar(25) not null,
age int,
salary int,
primary key(id));

create table department(
id int not null,
department_id int,
department_name varchar(25) not null,
primary key(department_id),
constraint fk_pd foreign key(id) references person(id));
drop table department;

# adding foreign key separatly after creating the table
create table department(
id int not null,
department_id int,
department_name varchar(25) not null,
primary key(department_id));
alter table department add foreign key(id) references person(id);

drop table department;
drop table person;

#Check constraints
create table person(
id int not null,
firstname varchar(25) not null,
lastname varchar(25) not null,
age int,salary int,
primary key(id),
check(salary<50000));
insert into person values(2,'Pavan1','B1',24,60000);
select * from person;
drop table person;
#Default constraints
create table person(
id int not null,
firstname varchar(25)not null,
lastname varchar(25)not null,
city_name varchar(25) default 'Hyd'
);

alter table person alter city_name drop default;
desc person

