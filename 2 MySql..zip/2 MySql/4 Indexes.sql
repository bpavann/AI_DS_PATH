#Indexing
/*
Create index statements in SQL is to create index in tables
Indexs are used to retrive data from database more quickly than others
The user can not see the index and they rae just used to speedup the queries and searches

Note:-Updating the indexes with tables takes lot of time than updating the table withoutout index.
Because indexes are also need to update.So, only create index on those columns that will be frequently search against.
*/

use customer;
select * from person;
select * from student;
create index index_cityname on person(city_name);
create index index_age on student(age);
#Compound indexing
create index index_age_firstname on student(age,firstname);
show index from student;
alter table student drop index index_age;
