/* Day 1 MySQL
/*
Show DB
use (DB)
Create DB
Create Table
Show Table
Inser Table
Drop DB
Drop Table
*/
create database customer;
use customer;
create table customer_info(id integer,firstname varchar(10),lastname varchar(10));
insert into customer_info(id,firstname,lastname) values(1,'pavan','kumar');
select * from customer_info;
drop table customer_info;
drop database customer;
show databases

