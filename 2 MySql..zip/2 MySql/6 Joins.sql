#Joins :- Retrive data from two or more database tables
/*
Inner Join
Left Join
Right Join
Full Join
Natural Join
Cross Join
*/
use customer;
select * from student;
insert into student values(4,'Pavan1','BB',24),(5,'don','k',23);
select * from  department;

#Inner join
select student.stu_id,student.firstname,student.age, department.dep_name from student inner join department on student.stu_id=department.stu_id;

#Left join/Left outer join
select student.stu_id,student.firstname,student.age, department.dep_name from student left join department on student.stu_id=department.stu_id;

#Right join/Right outer join
select student.stu_id,student.firstname,student.age, department.dep_name from student Right join department on student.stu_id=department.stu_id;

#we cant do the same as left and right outer join we need to use UNION for it
#Full Outer Join
select student.stu_id,student.firstname,student.age, department.dep_name from student left join department on student.stu_id=department.stu_id
union
select student.stu_id,student.firstname,student.age, department.dep_name from student Right join department on student.stu_id=department.stu_id;

#Cross Join :- No need of foreign key equalence
select student.stu_id,student.firstname,student.age, department.dep_name from student cross join department;
#it will give all the possibilities with the two tables

#Natural joins
select student.stu_id,student.firstname,student.age, department.dep_name from student natural join department;

/*
What are difference between SQL inner join and left join.?
What is the difference between left join and full join.?
What is the quary that will join these two tables,so that all the rows from table 1 are in the result.?
How do you retrive the data by using joins from more than two tables
*/