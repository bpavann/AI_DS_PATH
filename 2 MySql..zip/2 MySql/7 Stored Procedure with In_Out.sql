#Stored Procedure(our syntax or queries)
use customer;
select * from student;

#"In" parameter after creating stored Procedure
call get_stu_info_in(25);

#"out parameter" after creating stored Procedure
call get_stu_info_out(@records);# we need to get data and stored in a parameter and then retrive that data as you want
select @records as TotalRecords;

#"In and Out parameter as 'inout'" after creating the stored parameter
call get_s_info_in_out(25,@records);
select @records as Total_Records;