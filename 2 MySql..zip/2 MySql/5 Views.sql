use customers;

#VIEWS
/*
Views is a virtual table based on the result set on a SQL Quary.
*/
#auto increment
use customer;
create table student(stu_id int auto_increment,firstname varchar(25) not null,lastname varchar(25) not null,age int,primary key(stu_id) );
insert into student values(1,'Pavan','B',25),(2,'kc','y',22),(3,'suri','f',24);

create table department(stu_id int auto_increment,dep_name varchar(25) not null, foreign key(stu_id) references student(stu_id));
insert into department values(1,'CSE'),(2,'COM'),(3,'CIVIL');

select firstname,lastname,age from student inner join department using (stu_id);

create view student_info as select firstname,lastname,age from student inner join department using (stu_id);
drop view student_info;

