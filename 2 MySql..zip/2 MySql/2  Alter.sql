#Day 2
/*
Null values
Update statement
Delete statement
Alter table
    -add column in exisited column
    -modify/alter column
    -Alter yable / Drop cloumn
*/
create database customer;
use customer;
create table customer_info(id integer,firstname varchar(10),lastname varchar(10),salary integer,primary key(id));
insert into customer_info(id,firstname,lastname,salary) 
values
(1,'pavan','kumar',125),
(2,'kc','y',420),
(3,'suri','f',105),
(4,'tharun','n',640),
(5,'anji','k',null);
#Is NUll and Is not Null
select * from customer_info where salary is null;
select * from customer_info where salary is not null;

#Update statement to replace the nullwe got
update customer_info set salary=390 where id=5;
select * from customer_info;

#Delete statement
delete from customer_info where id=5;
select * from customer_info;

#Alter table
#-1) Add columns to udpate existing column
alter table customer_info add dob varchar(10);
alter table customer_info add email varchar(25);

#adding emails with respective each id
update customer_info set email='bpk@gmail.com' where id=1;
update customer_info set email='kcy@gail.com' where id=2;
update customer_info set email='tharunn@gmail.com' where id=4;
update customer_info set email='anjik@gmail.com' where id=5;
update customer_info set email='surif@gamil.com' where id=3;
select * from customer_info;

#Change the type and modifing the type of column
alter table customer_info modify dob year;

#schema of table 
desc customer_info;

#Alter drop column
alter table customer_info add gender varchar(10);
alter table customer_info drop column gender;
select * from customer_info

